$(document).ready(function() {


    function setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.$content.css({
            'overflow': 'hidden'
        });

        this.$element
            .find('.modal-body').css({
                'max-height': maxHeight,
                'overflow-y': 'auto'
            });
    }

    $('.modal').on('show.bs.modal', function() {
        $(this).show();
        setModalMaxHeight(this);
    });

    $(window).resize(function() {
        if ($('.modal.in').length != 0) {
            setModalMaxHeight($('.modal.in'));
        }
    });


    $(".toggle-btn").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    $('[data-toggle="tooltip"]').tooltip();



    $('ul.nav.nav-tabs  a').click(function(e) {
        e.preventDefault();
        $(this).tab('show');
    });


    var response = false;

    function responsiveTabs() {
        if (response) {
            return false;
        }
        response = true;
        fakewaffle.responsiveTabs(['xs']);
    }

    function chartRender() {
        console.log("dfgdfgdf")
        var chart = new CanvasJS.Chart("chartContainer", {
            theme: "theme2",
            title: {
                text: ""
            },
            animationEnabled: true,
            axisX: {
                valueFormatString: "MMM",
                interval: 1,
                intervalType: "month"

            },
            axisY: {
                includeZero: false,
                gridColor: "#F2EFF5"

            },
            data: [{
                    lineColor: "#55426D",
                    type: "line",
                    markerColor: "#31253F",
                    //lineThickness: 3,        
                    dataPoints: [
                        { x: new Date(2012, 00, 1), y: 450 },
                        { x: new Date(2012, 01, 1), y: 414 },
                        { x: new Date(2012, 02, 1), y: 520, indexLabel: "highest", markerColor: "red", markerType: "triangle", borderColor: "red" },
                        { x: new Date(2012, 03, 1), y: 460 },
                        { x: new Date(2012, 04, 1), y: 450 },
                        { x: new Date(2012, 05, 1), y: 500 },
                        { x: new Date(2012, 06, 1), y: 480 },
                        { x: new Date(2012, 07, 1), y: 480 },
                        { x: new Date(2012, 08, 1), y: 410, indexLabel: "lowest", markerColor: "#55426D", markerType: "cross" },
                        { x: new Date(2012, 09, 1), y: 500 },
                        { x: new Date(2012, 10, 1), y: 480 },
                        { x: new Date(2012, 11, 1), y: 510 }

                    ]
                }


            ]
        });
        chart.render();
    }


    $('#agencyQuotaTab').on('shown.bs.tab', function(e) {
        chartRender();
    })


    $('.clickable-row').on('click', function(e) {


        //e.preventDefault();

        $('.clickable-row').removeClass('active');
        $(this).addClass('active');

        responsiveTabs();
        //chartRender();
        // responsiveTabs();
        if ($(e.currentTarget).hasClass('agent')) {
            $('#pageDetails').hide();
            $('#agentDetails').fadeIn();
            $('#page-content-wrapper').animate({
                scrollTop: $("#agentDetails").offset().top - 90
            }, 800);
        } else {
            $("#agentDetails").hide();
            $('#pageDetails').fadeIn();
            $('#page-content-wrapper').animate({
                scrollTop: $("#pageDetails").offset().top - 90
            }, 800);
        }

        $('.clickable-row-toggle').removeClass('active')
        $('.suspended-text').show();
        $('.surety-status.active').show();
        $('.surety-status.in-active').hide();

    });
    $('.clickable-row-toggle').on('click', function(e) {
        $('.clickable-row').removeClass('active');
        $(this).addClass('active');
        $('#pageDetails').fadeIn();
        responsiveTabs();
        $('#page-content-wrapper').animate({
            scrollTop: $("#pageDetails").offset().top - 90
        }, 800);
        $('.suspended-text').hide();
        $('.surety-status.active').hide();
        $('.surety-status.in-active').show();
    });


    $('body').on('click', '.graph-filter .btn', function(e) {
        chartRender();
    })


    $(".select-box").change(function() {
        if (this.value == 'active') {
            $('.suspension-history-table').hide();
        } else {
            $('.suspension-history-table').show();
        }
    });



    $('body').on('click', '.dropdown.filter-dropdown .dropdown-toggle', function(event) {
        $(this).parent().toggleClass('open');
    });

    $('body').on('click', function(e) {
        if (!$('.dropdown.filter-dropdown').is(e.target) && $('.dropdown.filter-dropdown').has(e.target).length === 0 && $('.open').has(e.target).length === 0) {
            $('.dropdown.filter-dropdown').removeClass('open');
        }
    });



    $('[data-toggle="tooltip"]').tooltip()



});
